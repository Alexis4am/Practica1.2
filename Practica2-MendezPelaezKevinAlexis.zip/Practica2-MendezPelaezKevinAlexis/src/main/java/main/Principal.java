package main;
import modelo.*;
import java.util.Scanner;


public class Principal {
	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		//INICIO
		System.out.println("Buenas, estas en E-Commerse, por favor registrate...");
		System.out.println("-------------------");
		//REGISTRO
		System.out.println("Nombre de Usuario:	");
		String idUsuario = in.nextLine();
		System.out.println("Contraseña:	");
		String contraseina = in.nextLine();
		System.out.println("Direccion a entregar:");
		String direccion = in.nextLine();
		
		//INSTANCIA DE USUARIO CREADO CON SCANNER
		Usuario usuario1 = new Usuario(idUsuario,contraseina, direccion);
		
		//MUESTRA LA INFORMACION DEL USUARIO
		System.out.println("-----------");
		System.out.println("Usuario es: " + usuario1.getIdUsuario());
		System.out.println("Contraseina es: " + usuario1.getContraseina());
		System.out.println("Direccion de envio es: " + usuario1.getDireccion());
		System.out.println("-----------");
		
		usuario1.getContraseina();
		//CREACION DE PRODUCTOS DISPONIBLES 
		//ROPA
		Ropa ropita1 = new Ropa("Gucci Sombrero de Fossil", 999.99, "M");
		Ropa ropita2 = new Ropa("Brazalete De Balenciaga", 99.99, "S");
		Ropa ropita3 = new Ropa("Medias", 50, "M");
		//ELECTRONICO
		Electronico electronico1 = new Electronico("Laptop Dell", 1450.99, 9923);
		Electronico electronico2 = new Electronico("Google Pixel 7a", 499.50, 7654);
		Electronico electronico3 = new Electronico("Tablet Apple", 899.50, 4321);
		
		//INSTANCIA DEL CARRITO DE USUARIO
		Carrito carrito = new Carrito();
		//INSTANCIA DE OTROS 2 PEDIDOS
		Pedido pedido1 = new Pedido(223);
		Pedido pedido2 = new Pedido(163);
		
		//Precio TOTAL
		double precio = 0.0;
		//MENU
		 while (true) {
			 	//ENTRAR:
			 	System.out.println("----MENU TIENDA----");
	            System.out.println("1. Ver Productos Ropa");
	            System.out.println("2. Ver Productos Electrico");
	            System.out.println("3. Salir");
	            String opcion = in.nextLine();
	            
	            //PRESENTACION
	            if (opcion.equals("1")) {
	            	System.out.println("-----------");
	                System.out.println("1. Modelo: "+ropita1.getNombreProducto());
	                System.out.println("Precio: "+ropita1.getPrecio());
	                System.out.println("-----------");
	                System.out.println("2. Modelo: "+ropita2.getNombreProducto());
	                System.out.println("Precio: "+ropita2.getPrecio());
	                System.out.println("-----------");
	                System.out.println("3. Modelo: "+ropita3.getNombreProducto());
	                System.out.println("Precio: "+ropita3.getPrecio());
	                System.out.println("-----------");
	                System.out.println("Desea agregar algo al carrito? ");
	                System.out.println("1. Si");
	                System.out.println("2. No");
	                String opcionR = in.nextLine();
	                
	                if (opcionR.equals("1")) {
	                	//AGREGAR MODELO Y CREAR INSTANCIA DE CARRITO
	                	System.out.println("Numero del modelo:");
	                	String carro = in.nextLine();
	                	if(carro.equals("1")) {
	                		carrito.agregarProducto(electronico1.getNombreProducto(), electronico1.getPrecio());
	                		precio = precio + electronico1.getPrecio();
	                	} else if (carro.equals("2")) {
	                		carrito.agregarProducto(electronico2.getNombreProducto(), electronico2.getPrecio());
	                		precio = precio + electronico1.getPrecio();
	                	} else if (carro.equals("3")) {
	                		carrito.agregarProducto(electronico3.getNombreProducto(), electronico3.getPrecio());
	                		precio = precio + electronico1.getPrecio();
	                	}
	                	System.out.println("Agregado!");
	                	
	                } else {
	                	System.out.println("Saliendo a menu...\n");
	                }
	                
	                //PRESENTACION
	            } else if (opcion.equals("2")) {
	            	System.out.println("-----------");
	            	System.out.println("1. Modelo: "+electronico1.getNombreProducto());
	             	System.out.println("Precio: "+electronico1.getPrecio());
	                System.out.println("-----------");
	                System.out.println("2. Modelo: "+electronico2.getNombreProducto());
	             	System.out.println("Precio: "+electronico2.getPrecio());
	                System.out.println("-----------");
	                System.out.println("3. Modelo: "+electronico3.getNombreProducto());
	             	System.out.println("Precio: "+electronico3.getPrecio());
	             	System.out.println("-----------");
	             	System.out.println("Desea agregar algo al carrito? ");
	             	System.out.println("1. Si");
	                System.out.println("2. No");
	                String opcionE = in.nextLine();
	                
	                if (opcionE.equals("1")) {
	                	//AGREGAR MODELO Y CREAR INSTANCIA DE CARRITO 
	                	System.out.println("Numero del modelo:");
	                	String carro = in.nextLine();
	                	if(carro.equals("1")) {
	                		carrito.agregarProducto(electronico1.getNombreProducto(), electronico1.getPrecio());
	                		precio = precio + electronico1.getPrecio();
	                	} else if (carro.equals("2")) {
	                		carrito.agregarProducto(electronico2.getNombreProducto(), electronico2.getPrecio());
	                		precio = precio + electronico1.getPrecio();
	                	} else if (carro.equals("3")) {
	                		carrito.agregarProducto(electronico3.getNombreProducto(), electronico3.getPrecio());
	                		precio = precio + electronico1.getPrecio();
	                	}
	                	System.out.println("Agregado!");
	                } else {
	                	System.out.println("Saliendo a menu...\n");
	                }
	              //OPCION 3(SALIR)  
	            } else if (opcion.equals("3")) {
	            	System.out.println("");
	                break; //The end(CIERRE)
	                
	              //SI NO EXISTE   
	            } else {
	                System.out.println("OPCION NO VALIDA, seleccione 1, 2 o 3.");
	            }
	        }	
		 Pedido pedido3 = new Pedido(000);
		 System.out.println("GRACIAS POR VISITAR LA TIENDA");
		 if (precio > 0.00) {
			 System.out.println("Su total a sido: " + precio);
			 pedido3.setCodigoPedido(332);
		 }
		 
		 
		//Mostrar informacion (EL FINAL DEL PROGRAMA);
		 //CON METODO toString
		 //PRODUCTOS ROPA|ELECTRONICO
		//ROPA
		System.out.println("Instancias de Ropa: ");
		System.out.println("-----------");
		System.out.println(ropita1.toString());
		System.out.println(ropita2.toString());
		System.out.println(ropita3.toString());
		System.out.println("-----------");
		 
		//ELECTRONICO
		System.out.println("Instancias de Electronico: ");
		System.out.println("-----------");
		System.out.println(electronico1.toString());
		System.out.println(electronico2.toString());
		System.out.println(electronico3.toString());
		System.out.println("-----------");
		
		//PEDIDOS
		System.out.println("Instancias de Pedido: ");
		System.out.println("-----------");
		System.out.println(pedido1.toString());
		System.out.println(pedido2.toString());
		System.out.println("este: "+ pedido3.toString());
		System.out.println("-----------");
		
		//USUARIO
		System.out.println("Instancia de Usuario: ");
		System.out.println("-----------");
		System.out.println(usuario1.toString());
		System.out.println("-----------");
		
		//CARRITO
		System.out.println("Instancia de Carrito: ");
		System.out.println("-----------");
		System.out.println(carrito.toString());
		System.out.println("-----------");
		
		in.close();
	}
}
