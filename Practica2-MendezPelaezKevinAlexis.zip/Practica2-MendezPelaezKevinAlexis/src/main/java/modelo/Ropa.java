package modelo;

public class Ropa extends Producto {
    private String talla;

	public Ropa(String nombreProducto, double precio, String talla) {
		super(nombreProducto, precio);
		this.talla = talla;
	}
	//METODOS SETTERS Y GETTERS
	public String getTalla() {
		return talla;
	}

	public void setTalla(String talla) {
		this.talla = talla;
	}

	@Override
	public String toString() {
		return super.toString()+ "\n" + "Ropa [talla=" + talla + "]";
	}


	
	

    
	


    
    
}
