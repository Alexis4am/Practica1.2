package modelo;
import java.util.ArrayList;
import java.util.List;

public class Carrito {
	private int numeroProductos;
	/*COMPOSICION DE PRODUCTO Y CARRITO
	Un carrito deja de existir si no hay 
	una instancia de un producto
	*/
	private List<Producto> productos;
	
	
    //CONSTRUCTOR
	public Carrito() {
		this.productos = new ArrayList<>();
	}
	
	//METODO ANIADIR AL CARRITO
	public void agregarProducto(String nombreProducto, double precio) {
        Producto producto = new Producto(nombreProducto, precio);
        productos.add(producto);
    }
	//METODOS SETTERS Y GETTERS
    public List<Producto> getProductos() {
        return productos;
    }
   
	public void setProductos(List<Producto> productos) {
		this.productos = productos;
	}
	public int getNumeroProductos() {
		return numeroProductos;
	}
	public void setNumeroProductos(int numeroProductos) {
		this.numeroProductos = numeroProductos;
	}
	
	@Override
	public String toString() {
		return "Carrito [productos=" + productos + "]";
	}
    
	
}



