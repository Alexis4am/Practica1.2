package modelo;


public class Electronico extends Producto {
	private int modelo;

	public Electronico(String nombreProducto, double precio, int modelo) {
		super(nombreProducto, precio);
		this.modelo = modelo;
	}
	
	//METODOS SETTERS Y GETTERS
	public int getModelo() {
		return modelo;
	}

	public void setModelo(int modelo) {
		this.modelo = modelo;
	}

	@Override
	public String toString() {
		return super.toString() + "Electronico [modelo=" + modelo + "]";
	}

	


	
 
	
}
 


