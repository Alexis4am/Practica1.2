package modelo;


public class Pedido {
	private int codigoPedido;
    
    
    //CONSTRUCTOR
    public Pedido(int codigoPedido) {
        this.codigoPedido = codigoPedido;
        
    }
    
    
    
    //METODOS SETTERS Y GETTERS
    public int getCodigoPedido() {
		return codigoPedido;
	}
	public void setCodigoPedido(int codigoPedido) {
		this.codigoPedido = codigoPedido;
	}


	//METODO toString
	@Override
	public String toString() {
		return "Pedido [codigoPedido=" + codigoPedido + "]";
	}
    
    
}

    

