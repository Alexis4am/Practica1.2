package modelo;
import java.util.ArrayList;
import java.util.List;

public class Usuario {
    private String idUsuario;
    private String contraseina;
    private String direccion;
    //AGREGACION DE USUARIO Y CARRITO
    private Carrito carrito;
    //ASOCIACION ENTRE USUARIO Y PEDIDOS
    private List<Pedido> pedidos;
    
    //CONSTRUCTOR ARRAY
    public Usuario(){
    	this.pedidos = new ArrayList<>();
    }
    //CONSTRUCTOR ENTERO
    public Usuario(String idUsuario, String contraseina,String direccion ) {
        this.idUsuario = idUsuario;
        this.contraseina = contraseina;
        this.direccion = direccion;
        this.pedidos = new ArrayList<>();
    }
    
    //METODOS SETTERS Y GETTERS
    public String getIdUsuario() {
        return idUsuario;
    }
    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }
	public Carrito getCarrito() {
        return carrito;
    }
    public void setCarrito(Carrito carrito) {
        this.carrito = carrito;
    }
	public String getContraseina() {
		return contraseina;
	}
	public void setContraseina(String contraseina) {
		this.contraseina = contraseina;
	}
	public List<Pedido> getPedidos() {
		return pedidos;
	}
	public void setPedidos(List<Pedido> pedidos) {
		this.pedidos = pedidos;
	}
    
	public void agregarPedido(Pedido pedido) {
        pedidos.add(pedido);
    }
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	
	@Override
	public String toString() {
		return "Usuario [idUsuario=" + idUsuario + ", contraseina=" + contraseina + ", carrito=" + carrito
				+ ", pedidos=" + pedidos + "]";
	}


    
    
}
